<?php
	/* Função para redirecionar a navegação*/
	header("location: view/admin.php");	

	exit;
?>