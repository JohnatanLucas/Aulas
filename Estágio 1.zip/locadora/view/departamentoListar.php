<div class="table-responsive">
    <table class="table table-striped table-bordered table-hover" id="dataTables-clientes">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Responsável</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($_array = mysql_fetch_assoc($result)) {
                ?>	
                <tr class="odd gradeX">
                    <td><?= $_array['IDDEPARTAMENTO'] ?></td>
                    <td><?= $_array['NOME'] ?></td>
                    <td><?= $_array['RESPONSAVEL'] ?></td>
                    <td width="102px">
    <!--                        <a href="#" class="btnAlterar" id="<?= $_array['IDDEPARTAMENTO'] ?>">
                            <i class="btn btn-info btn-sm"></i>Deta
                        </a>
                        &nbsp;
                        <a href="#" class="btnExcluir" id="<?= $_array['IDDEPARTAMENTO'] ?>">
                            <i class="fa fa-trash-o fa-fw"></i>Exc
                        </a>-->
                        <a href="#" class="btnEditar btn btn-info btn-sm" value="Editar" title="Editar" id="<?= $_array['IDDEPARTAMENTO'] ?>" >
                            <i class="fa fa-edit"></i>
                        </a>&nbsp&nbsp
                        <a class="btnExcluir btn btn-danger btn-sm" value="Apagar" title="Apagar" id="<?= $_array['IDDEPARTAMENTO'] ?>">
                            <i class="fa fa-trash-o"></i>
                        </a>

                    </td>
                </tr> 
                <?php
            }
            ?>
        </tbody>
    </table>

</div>
<!-- /.panel-body -->

<!-- Page-Level Demo Scripts - Tables - Use for reference -->

<script>

    $(document).ready(function () {
        $('#dataTables-veiculos').dataTable();

    });

    $(".btnAlterar").click(function () {
        $("#page-wrapper").load("/locadora/controller/ctrlReceiveForm.php", {
            //variaveis de controle
            txtFormulario: 'cliente'
            , txtAcao: 'detalhe'
                    //variaveis para o objeto
            , txtIdCliente: this.id
        }, function (responseTxt, statusTxt, xhr) {
            if (statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
    });

    $(".btnExcluir").click(function () {
        if (confirm('Deseja realmente excluir o registro?')) {
            $("#page-wrapper").load("/locadora/controller/ctrlReceiveForm.php", {
                //variaveis de controle
                txtFormulario: 'departamento'
                , txtAcao: 'excluir'
                        //variaveis para o objeto
                , txtIdDepartamento: this.id
            }, function (responseTxt, statusTxt, xhr) {
                if (statusTxt == "error")
                    alert("Error: " + xhr.status + ": " + xhr.statusText);
            });
        }
    });

</script>
