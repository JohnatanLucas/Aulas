    
<!--Mensagens Feedback-->
<div class="row">
    <div id="Mensagem" class="col-lg-12">
        
    </div>
</div>

<!--Título Página-->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Departamento</h1>
    </div>
</div>


<div class="row">
    <div class="col-lg-12">
    </div>
</div>

<!--Painel de inserção (Departamento)-->
<div class="row">

    <div class="col-lg-12">
        <div class="panel panel-default">

            <!--Titulo tabela-->
            <div class="panel-heading">
                <i class="fa fa-edit fa-fw"></i> Cadastro de Departamento
            </div>

            <!--Tabela dados internos-->
            <div class="panel-body">
                <form role="form" id="formAtual" name="formAtual">

                    <!--Linhas-->
                    <div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Nome</label>
                                    <input class="form-control" placeholder="Informe o nome do Departamento" type="text" id="txtNome" name="txtNome">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Responsável</label>
                                    <input class="form-control" placeholder="Informe o responsável pelo Departamento" type="text" id="txtResponsavel" name="txtResponsavel">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Botões-->
                    <div class="row">
                        <div class="col-lg-12" align="right">
                            <input type="hidden" name="txtFormulario" id="txtFormulario" value="departamento" >
                            <input type="hidden" name="txtAcao" id="txtAcao" value="incluir">
                            <button tabindex="5" type="button" class="btn btn-default btn-success fa fa-check" id="btnEnviar"> Salvar</button>
                        </div>
                    </div>
                </form>
            </div>
            <!-- /.row (nested) -->
        </div>
        <!-- /.panel-body -->
    </div>
</div>

<!--Tabela Lista De Departamento-->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-table fa-fw"></i> Lista de Departamentos
            </div>

            <!--Leitura dos dados da tabela-->
            <div class="panel-body" id="ListaDepartamento" name="ListaDepartamento">

            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
    </div>
</div>



<!--JS JavaScript--> 
<script type="text/javascript">
    $(document).ready(function () {
        $("#ListaDepartamento").load("../controller/ctrlReceiveForm.php", {
            //variaveis de controle
            txtFormulario: "departamento"
            , txtAcao: "listar"
        }, function (responseTxt, statusTxt, xhr) {
            if (statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
    });


    $("#btnEnviar").click(function () {
        $("#Mensagem").load("../controller/ctrlReceiveForm.php", {
            //Váriaveis Padrão de Controle
            txtFormulario: document.forms["formAtual"].elements["txtFormulario"].value
            , txtAcao: document.forms["formAtual"].elements["txtAcao"].value
                    //Váriaveis Editáveis de Inserção
            , txtNome: document.forms["formAtual"].elements["txtNome"].value
            , txtResponsavel: document.forms["formAtual"].elements["txtResponsavel"].value
        }, function (responseTxt, statusTxt, xhr) {
            if (statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
    });


</script>












