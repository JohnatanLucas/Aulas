<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Locadora - Painel adminstrativo</title>

    <!-- Core CSS - Include with every page -->
    <link href="/locadora/include/css/bootstrap.min.css" rel="stylesheet">
    <link href="/locadora/include/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- SB Admin CSS - Include with every page -->
    <link href="/locadora/include/css/sb-admin.css" rel="stylesheet">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Por favor, informe seu usuário e senha</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" action="/locadora/controller/ctrlReceiveForm.php" name="formLogin" id="formLogin" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Usuário" name="txtLogin" type="text" autofocus="autofocus">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Senha" name="txtSenha" type="password" value="">
                                </div>
                                <input class="form-control" name="formulario" type="hidden" value="login">
                                <input class="form-control" name="acao" type="hidden" value="login">
                                <!-- Change this to a button or input when using this as a form -->
                                <a href="javascript:formLogin.submit();" class="btn btn-lg btn-success btn-block">Acessar</a>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core Scripts - Include with every page -->
    <script src="/locadora/include/js/jquery-1.10.2.js"></script>
    <script src="/locadora/include/js/bootstrap.min.js"></script>
    <script src="/locadora/include/js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- SB Admin Scripts - Include with every page -->
    <script src="/locadora/include/js/sb-admin.js"></script>

</body>

</html>
