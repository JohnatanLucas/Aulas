

<div class="alert alert-success" id="alerta" role="alert">
    <!-- <button class="close" data-dimiss="modal">&times;</button>-->
    <?= $texto ?>
    <!-- <p align="center"><input class="btn btn-default" type="button" id="btnOk" name="btnOk" value="Okay"></p>-->
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>                
</div>
<script type="text/javascript">
    $('#alerta').show();
</script>

