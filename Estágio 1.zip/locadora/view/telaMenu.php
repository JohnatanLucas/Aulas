<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<title>Principal</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">	
</head>

<body>
	<div align="center">
    		<b>funcionario</b>
            <br>
			<a href="../view/funcionarioIncluir.php">funcionario incluir</a><br>
			<a href="../controller/ctrlReceiveForm.php?formulario=funcionario&acao=listar">funcionario listar</a><br>
	</div>
	<br>
</body>
</html>
